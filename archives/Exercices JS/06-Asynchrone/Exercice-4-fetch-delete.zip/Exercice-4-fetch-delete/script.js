//  `http://localhost:3000/heroes`

document.getElementById("run").addEventListener("click", async () => {
  let id = document.getElementById("index").value;
  if (id === "") {
    alert("Veuillez entrer un nombre");
  }

  id = Number(id);

  if (Math.sign(id) === -1) {
    alert("Pas de nombre négatif");
  }

  await fetch(`http://localhost:3000/heroes/${id}`, {
    method: "DELETE",
  });

  await fetch("http://localhost:3000/heroes")
    .then((resp) => resp.json())
    .then((data) => console.log(data));
});
